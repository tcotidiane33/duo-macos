
import duo_client
import sys

ikey = "DI2R1JCFFI015NUBSDPH"
skey = "2RgImDTH4N8oxvmxeacD4JfSq9QOiANCQ44MtWrH"
host = "api-8905b780.duosecurity.com"

print(f"Testing Auth API...")
auth_client = duo_client.Auth(ikey=ikey, skey=skey, host=host)
try:
    print("Auth Ping:", auth_client.ping())
    print("Auth Check:", auth_client.check())
except Exception as e:
    print("Auth API Error:", e)

print(f"\nTesting Admin API...")
admin_api = duo_client.Admin(ikey=ikey, skey=skey, host=host)
try:
    # A very simple admin call
    print("Admin settings:", admin_api.get_settings())
except Exception as e:
    print("Admin API Error:", e)
