Duo is committed to providing secure software to all our customers and users.  We take all security concerns seriously and ask that any disclosures be handled responsibly.

# Security Policy

## Reporting a Vulnerability
**Please do not use Github issues or pull requests to report security vulnerabilities.**

If you believe you have found a security vulnerability in Duo software, please follow our response process described at https://duo.com/support/security-and-reliability/security-response.
