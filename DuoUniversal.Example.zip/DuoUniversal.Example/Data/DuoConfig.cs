namespace DuoUniversal.Example.Data
{
    public class DuoConfig
    {
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string ApiHost { get; set; }
        public string RedirectUri { get; set; }
    }
}
